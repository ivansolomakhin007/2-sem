#include <iostream>
#include <stack>
#include <vector>

struct Square{ // клетка
    Square* from; // откуда пришли
    int x;
    int y;
    Square(Square* a, int b, int c){
        Square* from = a; // откуда пришли
        int x = b;
        int y = c;
    };
};

bool in(Square* elem, std::vector<Square*> arr){
    int s = arr.size();
    for (int i = 0; i < s; i ++) {
        if (elem == arr[i]) {
            return true;
        }
    }
    return false;
};

int main() {
    int x_0, y_0;
    std::cin >> x_0;
    std::cin >> y_0;
    Square start = Square(nullptr, x_0, y_0);
    Square* field[6][6]; // создаем поле
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j < 6; j++) {
            field[i][j] = new Square(nullptr, j, i);
        }
    }
    field[y_0][x_0] = &start;
    std::stack<Square*> stack;
    std::pair<int, int> motion[8] = {{+1, +2}, {+2, +1}, {-1, 2}, {2, -1},
                                     {1, -2}, {-2, 1}, {-1, -2}, {-2, -1}};
    stack.push(&start);
    std::vector<std::vector<Square*>> used;
    std::vector<Square*> local_used;
    while (stack.size() > 0) {
        // проходимся по моушенсу
        int x, y;
        //std::vector<Square*> local_used;
        Square* element = stack.top();
        stack.pop();
        bool is_motion = false;
        local_used.push_back(element); //создаем локальное хранилище
        for (int i = 0; i < 8; i++) {
            x = element->x + motion[i].first;
            y = element->x + motion[i].second;
            if (x >= 0 & x <= 6 & y >= 0 & y <= 6) {
                if (!in(field[y][x], local_used)) {
                    element->from = field[y][x];
                    stack.push(field[y][x]);
                    local_used.push_back(field[y][x]);
                    is_motion = true;
                }
            }
        }
        if (is_motion == false) {
            if (local_used.size() < 34) {
                used.push_back(local_used);
                local_used.clear();
            }
            else {
                for (int i = 0; i < local_used.size(); i ++) {
                    std::cout << local_used[i]->x;
                }
                return 0;
            }
        }
    }


    return 0;
}
