#include <iostream>
#include <vector>

int main() {
    int n, m;
    std::cin >> n;
    std::cin >> m;

     int* a = new int[n];
     int* b = new int[n];
    for (int i=0; i < n; i ++) {
        std::cin >> *(a + i);
    }
    for (int i=0; i < n; i ++) {
        *(b + i) = *(a  + (i + m) % n);
    }
    for (int i=0; i < n; i ++) {
       std::cout << b[i] << ' ';
    }
    delete [] a;
    delete [] b;

    return 0;
}
