#include <iostream>
#include <vector>

int main() {
    int n;
    std::cin >> n;

    int* a = new int[n];
    // вспомогательная переменная для обмена значений
    int c;
    for (int i=0; i < n; i ++) {
        std::cin >> *(a + i);
    }


    for (int i=0; i < n; i++) {
        for (int j=0; j < n - 1; j++) {
            if (a[j] > a[j + 1]) {
                c = a[j];
                a[j] = a[j + 1];
                a[j + 1] = c;
            }

        }
    }
    for (int i=0; i < n; i ++) {
        std::cout << a[i] << ' ';
    }

    delete [] a;

    return 0;
}#include <iostream>
#include <vector>

int main() {
    int n;
    std::cin >> n;

    int* a = new int[n];
    // вспомогательная переменная для обмена значений
    int c;
    for (int i=0; i < n; i ++) {
        std::cin >> *(a + i);
    }


    for (int i=0; i < n; i++) {
        for (int j=0; j < n - 1; j++) {
            if (a[j] > a[j + 1]) {
                c = a[j];
                a[j] = a[j + 1];
                a[j + 1] = c;
            }

        }
    }
    for (int i=0; i < n; i ++) {
        std::cout << a[i] << ' ';
    }

    delete [] a;

    return 0;
}