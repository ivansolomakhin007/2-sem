#include <iostream>
#include <vector>

int main() {
    int n;
    std::cin >> n;

    int* a = new int[n];
    // вспомогательная переменная для обмена значений
    int c;
    for (int i=0; i < n; i ++) {
        std::cin >> *(a + i);
    }

    for (int i=0; i < n; i++) {
        for (int j=0; j < n - 1; j++) {
            if (a[j] > 0 && a[j + 1] > 0) { //|| a[j] > 0 && a[j + 1] < 0 вторая часть условия
                if (a[j] > a[j + 1]) {
                    c = a[j];
                    a[j] = a[j + 1];
                    a[j + 1] = c;
                    for (int i=0; i < n; i ++) {
                        std::cout << a[i] << ' ';
                    }
                    std::cout << std::endl;
                }
            }
            else if (a[j] > 0 && a[j + 1] < 0 || a[j] < 0 && a[j + 1] > 0) {
                for (int k=j + 2; k < n - j; k ++) {
                    if  (a[j] * a[j + k] > 0) {
                        if (a[j] > a[j + k]  && a[j] > 0) {
                            c = a[j];
                            a[j] = a[j + k];
                            a[j + k] = c;

                        }
                        else if (a[j] < a[j + k]  && a[j] < 0) {
                            c = a[j];
                            a[j] = a[j + k];
                            a[j + k] = c;
                        }
                    }
                }
            }
            else if (a[j] < 0 && a[j + 1] < 0) {
                if (a[j] < a[j + 1]) {
                    c = a[j];
                    a[j] = a[j + 1];
                    a[j + 1] = c;
                    for (int i=0; i < n; i ++) {
                        std::cout << a[i] << ' ';
                    }
                    std::cout << std::endl;
                }
            }

        }

    }

    delete [] a;

    return 0;
}