#include <iostream>
#include <vector>

int main() {
    int n;
    std::cin >> n;

    int* a = new int[n];
    int* b = new int[n];
    for (int i=0; i < n; i ++) {
        std::cin >> *(a + i);
    }
    for (int i=0; i < n; i ++) {
        *(b + i) = (*(a  + (i - 1 + n) % n) +  *(a  + i) + *(a  + (i + 1 + n) % n)) / 3;
    }
    for (int i=0; i < n; i ++) {
        std::cout << b[i] << ' ';
    }
    delete [] a;
    delete [] b;

    return 0;
}
