#include <iostream>

int main() {
    int n;
    std::cin >> n;

    int* a = new int[n];
    int* b = new int[n];

    for (int i=0; i < n; i ++) {
        std::cin >> *(a + i);
    }
    for (int i=0; i < n; i ++) {
        *(b + i) = *(a  + n - i - 1);
    }
    for (int i=0; i < n; i ++) {
        std::cout << b[i] << ' ';
    }
    delete [] a;
    delete [] b;

    return 0;
}
