int* now_get_me_some_bytes(unsigned int size) {
    int *arr_p = new int [size];
    return arr_p;
}

void now_free_some_bytes(int *p) {
    delete [] p;
}
