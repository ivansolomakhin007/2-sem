#include <iostream>
#include <vector>

int main() {
    int n;
    std::cin >> n;
    // выделяем память под n элементов :)
    std::vector<int> v;
    int a;
    int v_sum = 0;
    for (int i = 0; i < n; i++) {
        std::cin >> a;
        v_sum += a;
        v.push_back(a);
    }
    double v_avg = double(v_sum) / double(n);
    int sum = 0;
    for (int i = 0; i < n; i++) {
        if (v[i] > v_avg) {
            sum += v[i];
        }
    }
    std::cout << sum;
    return 0;
}