void print_array(int* p) {
    for (int i = 0; i < 6; i++) {
        cout << *(p + i) << " ";
    }
}
