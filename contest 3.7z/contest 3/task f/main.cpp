int* my_slightly_dumb_reallocation(int* source, unsigned int n_old, unsigned int n_new){
    if (n_new == 0) {
        if (source != NULL) {
            delete [] source;
        }
        return NULL;
    }
    int *new_arr = new int[n_new];
    if (source != NULL) {
        unsigned int a;
        if (n_old >= n_new) {
            a = n_new;
        }
        else {
            a = n_old;
        }
        for (int i = 0; i < a; i++) {
            new_arr[i] = source[i];
    }
        delete [] source;
    }
    return new_arr;
}
