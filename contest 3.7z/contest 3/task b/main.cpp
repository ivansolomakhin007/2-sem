#include <iostream>
#include <vector>

int main() {
    int N;
    int M;
    int K;
    std::cin >> N;
    std::cin >> M;
    std::cin >> K;
    // создаем минное в поле в переменной типа вектора целочисенных векторов field
    std::vector <std::vector <int>> field;
    // заполянем поле нулями
    for (int i = 0; i < N; i++) {
        std::vector <int> string;
        for (int j = 0; j < M; j++) {
            string.push_back(0);
        }
        field.push_back(string);
    }
    // раставляем мины
    std::vector <std::vector <int>> combinations = {{1, 0}, {0,1}, {-1, 0}, {0, -1}, {1, 1}, {-1, -1}, {1, -1}, {-1, 1}};
    for (int i = 0; i < K; i++) {
        int x;
        int y;
        std::cin >> x;
        std::cin >> y;
        field[x - 1][y - 1] = -1;
        for (auto &combination : combinations) {
            if (x - 1 + combination[0] < N && x - 1 + combination[0] >= 0 && y - 1 + combination[1] < M &&
                y - 1 + combination[1] >= 0) {
                if (field[x - 1 + combination[0]][y - 1 + combination[1]] != -1) {
                    field[x - 1 + combination[0]][y - 1 + combination[1]] += 1;
                }
            }
        }
    }

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < M; j++) {
            std::cout << field[i][j] << " ";
        }
        std::cout << std::endl;
    }
    return 0;
}