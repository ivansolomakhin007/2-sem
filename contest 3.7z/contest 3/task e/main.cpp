#include <iostream>

int main() {
    int a;
    int b;
    std::cin >> a;
    std::cin >> b;
    int c;
    c = do_some_awesome_work(&a, &b);
    std::cout << c;
    return 0;
}
