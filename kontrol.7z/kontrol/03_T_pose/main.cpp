#include <iostream>
#include <vector>

int main() {
    int n_x, n_y, k;
    std::cin >> n_x;
    std::cin >> n_y;
    std::cin >> k;
    std::vector<std::vector<char>> field;
    std::vector<char> str;
    for (int i = 0; i < n_y; i++) {
        for (int j = 0; j < n_x; j++) {
            str.push_back('*');
        }
        field.push_back(str);
    }
//    for (int i = 0; i < n_y; i++) {
//        for (int j = 0; j < n_x; j++) {
//            std::cout << field[i][j] << ' ';
//        }
//        std::cout << std::endl;
//    }
    int x;
    int y;
    for (int i = 0; i < k; i++) {
        std::cin >> x;
        std::cin >> y;
        field[y][x] = 'T';
    }

    for (int i = 0; i < n_y; i++) {
        for (int j = 0; j < n_x; j++) {
            std::cout << field[i][j];
        }
        std::cout << std::endl;
    }

    return 0;
}
