#include <iostream>
#include <cmath>
#include <iomanip>

int main() {
    double k;
    double h_0;
    double m;
    std::cin >> k;
    std::cin >> h_0;
    std::cin >> m;
    double v;
    v = h_0 * sqrt(2 * k / m);
    std::cout << std::fixed << std::setprecision(1) << v;
    return 0;
}

