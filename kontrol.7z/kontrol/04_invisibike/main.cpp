unsigned int is_an_invisible_bike(Vehicle* v, unsigned int n) {
    unsigned int count = 0;
    for (int i = 0; i < n; i++) {
        if (v[i].is_visible == false && v[i].type == 1) {
            count += 1;
        }
    }
    return count;

}

