
void rip_samurai(const Track *all_songs, unsigned int all_n, Track **in_memoriam_johnny, unsigned int* johnny_n) {
    int cap = 0;
    for (int i = 0; i < all_n; i++) {
        if (all_songs[i].author == 0) {
            cap += 1;
        }
    }
    Track* a;
    if (cap == 0) {
        a = nullptr;
    }
    else {
        a = new Track[cap];
    }
    int start = 0;
    for (int i = 0; i < all_n; i++) {
        if (all_songs[i].author == 0) {
            a[start] = all_songs[i]; //waslkfhHGEILFGHAOIFGH;FIGUHG
            start += 1;
        }
    }
    *johnny_n = cap;
    *in_memoriam_johnny = a;
}

