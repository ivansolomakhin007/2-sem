//#include <iostream>
//
//struct BehaviorPattern {
//    BehaviorPattern *next, *prev;
//    void* cyphered_data;
//    unsigned long long int length; 	// terabytes
//    unsigned char type;		// 0 - neutral, 1 - friendly, 2 - agressive, 3 - cowardly, 4 - paranoid, 5 - pseudorandom
//};


//void fix_list(BehaviorPattern* root) {
//    if (root) {
//        root->prev = nullptr;
//        BehaviorPattern *a = root;
//        while (a->next != nullptr) {
//            BehaviorPattern *b = a;
//            a = a->next;
//            a->prev = b;
//        }
//    }
//}

//int main() {
//    std::cout << "Hello, World!" << std::endl;
//    return 0;
//}
