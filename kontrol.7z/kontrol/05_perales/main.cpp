bool rewrite_memories(int* begin, int* end, int* fake, unsigned int n) {
    unsigned int n_before = end - begin + 1; //
    if (n == n_before) {
        for (unsigned int i = 0; i < n; i++) {
            begin[i] = fake[i];
        }
        return true;
    }
    else if (n_before < n) {
        for (unsigned int i = 0; i < n_before; i++) {
            begin[i] = fake[i];
        }
        return false;

    }
    else if (n < n_before) {
        for (unsigned int i = 0; i < n; i++) {
            begin[i] = fake[i];
        }
        return false;

    }
    return false;

}
