#include <iostream>

int main() {
    std::cout << "Cyberpunk2077" << std::endl;
    return 0;
}
