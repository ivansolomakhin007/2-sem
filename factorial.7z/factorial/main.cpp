#include <iostream>

// следующие 3 функции возвращают факториалы разных типов
long long int long_long_int_factorial(long long int ar) {
    long long int res = 1;
    for (int i = 1; i <= ar; i++)
        res *= i;
    return res;
};

long int long_int_factorial(long int ar) {
    long int res = 1;
    for (int i = 1; i <= ar; i++)
        res *= i;
    return res;
};

int int_factorial(long int ar) {
    int res = 1;
    for (int i = 1; i <= ar; i++)
        res *= i;
    return res;
};

// проверяем является ли факториал, вычисленный нами факториалом,
// путем проверки делимости на числа от 1 до inp_num (числа подаваемого на вход)
bool check_factorial(long long int fact, long long int inp_num) {
    for (int i = 1; i <= inp_num; i++) {
        if (fact % i != 0) {
            return 0;
        }
    }
    return 1;
}

// следующие три функции находят максимыльное число факориал от которого в том или ином типе данных корректен
void max_int() {
    int i = 1;
    while (1) {
        int fact = int_factorial(i);
        if (check_factorial(fact, i)) {
            i += 1;
        }
        else {
            i -= 1;
            break;
        }
    }
    std::cout << "Max int factorial: " << i << std::endl;
}

void max_long_int() {
    int i = 1;
    while (1) {
        long int fact = long_int_factorial(i);
        if (check_factorial(fact, i)) {
            i += 1;
        }
        else {
            i -= 1;
            break;
        }
    }
    std::cout << "Max long int factorial: " << i << std::endl;
}

void max_long_long_int() {
    int i = 1;
    while (1) {
        long long int fact = long_long_int_factorial(i);
        if (check_factorial(fact, i)) {
            i += 1;
        }
        else {
            i-= 1;
            break;
        }
    }
    std::cout << "Max long long int factorial: " << i << std::endl;
}

int main() {
    long long int number;
    std::cin >> number;
    long long int res = long_long_int_factorial(number);
    std::cout << "Your factorial: " << res << std::endl;
    max_int();
    max_long_int();
    max_long_long_int();
    return 0;
}
