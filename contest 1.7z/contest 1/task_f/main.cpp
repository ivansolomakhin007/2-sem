#include <iostream>

int main() {
    int max = 0;
    int count = 0;
    int a;
    std::cin >> a;
    while (a != 0){
        if (a==max) {
            count += 1;
        }
        else if (a > max) {
            max = a;
            count = 1;
        }
        std::cin >> a;
    }
    std::cout << count;
    return 0;
}
