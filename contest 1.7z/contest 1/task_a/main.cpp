#include <iostream>

long long int euclide(long long int ar1,long long int ar2) {
    long long int c = ar1 % ar2;
    if (c==0){
        return ar2;
    }
    else{
        euclide(ar2, c);
    }
}

int main() {
    long long int number1, number2;
    std::cin >> number1;
    std::cin >> number2;
    std::cout << euclide(number1, number2) << std::endl;
    return 0;
}
