#include <iostream>

int main() {
    int number;
    std::cin >> number;
    int count = 0;
    for (int i = 1; i <= number; i++){
        if (number % i == 0) {
            count += 1;
        }
    }
    if (count == 2) {
        std::cout << 1;
    }
    else {
        std::cout << 0;
    }
    return 0;
}
