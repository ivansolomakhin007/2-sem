#include <iostream>

int main() {
    int count = 0;
    int a;
    std::cin >> a;
    while (a!=0) {
        if (a % 2 == 0) {
            count += 1;
        }
        std::cin >> a;
    }
    std::cout << count;
    return 0;
}
