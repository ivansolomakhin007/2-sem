#include <iostream>

int vavilon(int num){
    int r = num % 60;
    int q = num / 60;
    int count_recursion = 0;
    if (q > 0) {
        vavilon(q);
        count_recursion += 1;
    }
    if (count_recursion > 0) {
        std::cout << ".";
    }
    int count_unites = r % 10;
    int count_decades = r / 10;
    for (int i = 1; i <= count_decades; i++) {
        std::cout << "<";
    }
    for (int i = 1; i <= count_unites; i++) {
        std::cout << "v";
    }
    return 0;
}

int main() {
    int number;
    std::cin >> number;
    vavilon(number);
    return 0;
}
