#include <iostream>

int main() {
    int n;
    std::cin >> n;
    int value = 1;
    while (value < n){
        value *= 2;
    }
    if (value == n) {
        std::cout << "YES";
    }
    else {
        std::cout << "NO";
    }
    return 0;
}
