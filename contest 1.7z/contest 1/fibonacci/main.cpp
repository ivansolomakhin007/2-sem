#include <iostream>
#include <vector>

int cycle(int n) {
    int a1 = 1, a2 = 1;
    int an = 0;
    if (n==1) {
        return a1;
    }
    else if (n==2) {
        return a2;
    }
    else {
        for (int i = 2; i < n; i++) {
            an = a1 + a2;
            a1 = a2;
            a2 = an;
        }
        return an;
    }
}

int recursion(int n) {
    int a1 = 1, a2 = 1;
    int an;
    if (n==1) {
        return a1;
    }
    else if (n==2) {
        return a2;
    }
    an = recursion(n - 1) + recursion (n - 2);
    return an;
}

std::vector<int> a;
int optimal_recursion(int n) {
    if (n > a.size()) {
        //раньше заходим на двойке, чем на единицы, поэтому на двойке сразу добавляемдве единички
        if (n==2||n==1){
            a.push_back(1);
            a.push_back(1);
        }
        else{
            a.push_back(optimal_recursion(n - 1) + optimal_recursion(n - 2));
        } }
    return a[n - 1];
}

int main() {
    int n;
    std::cin >> n;
    //выбор функции
    std::cout << optimal_recursion(n);
    return 0;
}