#include <iostream>

int main() {
    int max = 0;
    int a;
    std::cin >> a;
    while (a!=0) {
        if (a % 2 == 0 && a > max) {
            max = a;
        }
        std::cin >> a;
    }
    std::cout << max;
    return 0;
}
