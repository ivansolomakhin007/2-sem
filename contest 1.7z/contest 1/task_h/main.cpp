#include <iostream>

int main() {
    int number;
    std::cin >> number;
    int i = 2;
    while (number > 1){
        if (number % i == 0) {
            number /= i;
            std::cout << i << std::endl;
        }
        else {
            i += 1;
        }
    }
    return 0;
}
