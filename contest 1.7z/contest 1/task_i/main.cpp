#include <iostream>
#include <string>

int plus_penalty(char ar[3]){
    if (ar[1] == ar[2] == ar[0]) {
        return 1000;
    }
    else if (ar[0] == ar[1] || ar[0] == ar[2] || ar[1] == ar[2]){
        return 500;
    }
    else {
        return 100;
    }
}


int main() {
    int speed;
    std::string num;
    std::string boss = {'A', '9', '9', '9', 'A', 'A'};
    std::cin >> speed >> num;
    int penalty = 0;
    while (num != boss) {
        if (speed > 60) {
            char num_digits[3] = {num[1], num[2], num[3]};
            penalty += plus_penalty(num_digits);
        }
        std::cin >> speed >> num;
    }
    std::cout << penalty;
    return 0;
}
