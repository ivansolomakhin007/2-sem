#include <iostream>
#include <vector>

int main() {
    std::vector<int> stack;
    int c;
    std::cin >> c;
    while (c != 0) {
        if (c > 0) {
            stack.push_back(c);
        }
        if (stack.size() > 0) {
            if (c < 0 && -c < stack[stack.size() - 1]) {
                stack[stack.size() - 1] += c;
            } else if (c < 0 && -c >= stack[stack.size() - 1]) {
                stack.pop_back();
            }
        }
        std::cin >> c; }

        if (stack.size() > 0) {
            std::cout << stack.size() << ' ' << stack[stack.size() - 1];
        } else {
            std::cout << stack.size() << ' ' << -1;
        }
        return 0;

}