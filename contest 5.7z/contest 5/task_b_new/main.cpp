#include <iostream>
#include <string>
#include <iterator>
#include <vector>
#include <sstream>

std::vector<std::string> recursion(std::vector<std::string> v) {
    int x;
    for (int i = 0; i < v.size(); i++){
        if (v[i] == "+") {
            x = stoi(v[i - 1]) + stoi(v[i - 2]);
            v.erase(v.begin() + (i - 2));
            v.erase(v.begin() + (i - 2));
            v.erase(v.begin() + (i - 2));
            v.insert(v.begin() + (i - 2), std::to_string(x));
            break;
        }
        else if (v[i] == "-") {
            x = stoi(v[i - 2]) - stoi(v[i - 1]);
            v.erase(v.begin() + (i - 2));
            v.erase(v.begin() + (i - 2));
            v.erase(v.begin() + (i - 2));
            v.insert(v.begin() + (i - 2), std::to_string(x));
            break;
        }
        else if (v[i] == "*") {
            x = stoi(v[i - 1]) * stoi(v[i - 2]);
            v.erase(v.begin() + (i - 2));
            v.erase(v.begin() + (i - 2));
            v.erase(v.begin() + (i - 2));
            v.insert(v.begin() + (i - 2), std::to_string(x));
            break;
        }
        else if (v[i] == "/") {
            x = stoi(v[i - 2]) / stoi(v[i - 1]);
            v.erase(v.begin() + (i - 2));
            v.erase(v.begin() + (i - 2));
            v.erase(v.begin() + (i - 2));
            v.insert(v.begin() + (i - 2), std::to_string(x));
            break;
        }

        }
    if (v.size() > 1) {
        v = recursion(v);
    }

    return v;
}


int main() {
    std::string line;
    std::getline(std::cin, line);
    std::istringstream iss(line);
    std::vector<std::string> stack((std::istream_iterator<std::string>(iss)), std::istream_iterator<std::string>());
    std::cout << recursion(stack)[0];
    return 0;
}
