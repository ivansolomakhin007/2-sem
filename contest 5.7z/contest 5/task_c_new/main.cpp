#include <iostream>
#include <string>
#include <vector>

int main() {
    std::vector<int> queue;
    int N;
    std::cin >> N;
    std::string a;
    for(int i = 0; i <= N; i++){
        std::getline(std::cin,a);

        if (a.length() > 1) {
            int b = stoi(a.substr(1, a.length() - 1));
            if (a[0] == '+') {
                queue.push_back(b);
            }
            else if (a[0] == '*') {
                if (queue.size() == 1) {
                    queue.push_back(b);
                }
                else if (queue.size() % 2 == 0) {
                    queue.insert(queue.begin() + queue.size() / 2, b);
                }
                else {
                    queue.insert(queue.begin() + queue.size() / 2 + 1, b);
                }
            }

        }
        if (a[0] == '-') {
            int c = queue[0];
            std::cout << c << std::endl;
            queue.erase(queue.begin());
        }

    }
    return 0;
}
