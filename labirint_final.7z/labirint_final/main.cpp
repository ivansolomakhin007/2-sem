#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <stack>
#include <queue>

struct Point {
    int x, y;
    Point* ptr;
    Point(){

    };
    Point(int x_1, int y_1){
        x = x_1;
        y = y_1;
    };
};

struct Maze {
    int sx, sy;
    int *map;
    Point *map_p;
    Point *start;
    Point *finish;

    void read(std::string filename) {
        std::fstream fin(filename);
        fin >> sx >> sy; // считываем размеры поля
        int *field = new int[sx * sy];
        Point* field_p = new Point[sx * sy];
        this->map = field;
        map_p = field_p;
        std::vector<Point> points;

        std::string str;
        std::getline(fin, str, '\n');
        for (int i = 0; i < sy; i++) {
            std::getline(fin, str);
            for (int j = 0; j < sx; j++) {
                if (str[j] == '#') {
                    this->map[j + i * sx] = -1;
                    map_p[j + i * sx] = Point(j, i);
                    map_p[j + i * sx].ptr = nullptr;
                }
                if (str[j] == ' ') {
                    this->map[j + i * sx] = -2;
                    map_p[j + i * sx] = Point(j, i);
                    map_p[j + i * sx].ptr = nullptr;
                }
                if (str[j] == 'I') {
                    this->map[j + i * sx] = -3;
                    map_p[j + i * sx] = Point(j, i);
                    map_p[j + i * sx].ptr = nullptr;
                    start = &(map_p[j + i * sx]);
                }
                if (str[j] == 'E') {
                    this->map[j + i * sx] = -4;
                    map_p[j + i * sx] = Point(j, i);
                    map_p[j + i * sx].ptr = nullptr;
                    finish = &(map_p[j + i * sx]);
                }
            }
        }

    };

    void save(std::string filename);

    void show();};


bool in(Point* elem, std::vector<Point*> arr){
    int s = arr.size();
    for (int i = 0; i < s; i ++) {
        if (elem == arr[i]) {
            return true;
        }
    }
    return false;};

//создаем функцию обхода в глубину, которая принимает на вход
void depth(Maze m) {
    std::vector<Point*> used;
    std::stack<Point*> stack;
    stack.push(m.start);
    Point* current = stack.top();
    stack.pop();
    while(current != m.finish){
        used.push_back(current);
        int x = (*current).x;
        int y = (*current).y;
        if (x + 1 < m.sx) {
            if (m.map[x + 1 + y * m.sx] != -1){
                stack.push(&m.map_p[x + 1 + y * m.sx]);
                if ((m.map_p[x + 1 + y * m.sx]).ptr == nullptr && &m.map_p[x + 1 + y * m.sx] != m.start) {
                    (m.map_p[x + 1 + y * m.sx]).ptr = current;
                }
            }
        }
        if (x - 1 >= 0){
            if (m.map[x - 1 + y * m.sx] != -1) {
                stack.push(&m.map_p[x - 1 + y * m.sx]);
                if ((m.map_p[x - 1 + y * m.sx]).ptr == nullptr && &m.map_p[x - 1 + y * m.sx] != m.start) {
                    (m.map_p[x - 1 + y * m.sx]).ptr = current;
                }
            }
        }
        if (y + 1 < m.sy) {
            if (m.map[x + (y + 1) * m.sx] != -1) {
                stack.push(&m.map_p[x + (y + 1) * m.sx]);
                if ((m.map_p[x + (y + 1) * m.sx]).ptr == nullptr && &m.map_p[x + (y + 1) * m.sx] != m.start) {
                    (m.map_p[x + (y + 1) * m.sx]).ptr = current;
                }
            }
        }
        if (y - 1 >= 0) {
            if (m.map[x + (y - 1) * m.sx] != -1) {
                stack.push(&m.map_p[x + (y - 1) * m.sx]);
                if ((m.map_p[x + (y - 1) * m.sx]).ptr == nullptr && &m.map_p[x + (y - 1) * m.sx] != m.start) {
                    (m.map_p[x + (y - 1) * m.sx]).ptr = current;
                }
            }
        }
        current = stack.top();
        stack.pop();
        while(in(current, used)) {
            current = stack.top();
            stack.pop();
        }

    }

    std::vector<Point*> way;
    way.push_back(current);

    while((*current).ptr != nullptr) {
        Point* next = (*current).ptr;
        current = next;
        way.push_back(current);
    }
    way.push_back(current);
    for(int i = 0; i < way.size(); i++) {
        std::cout << (*way[way.size() - 1 - i]).x << ' ' << (*way[way.size() - 1 - i]).y << std::endl;
    }
}


//создаем функцию обхода в глубину, которая принимает на вход
void width(Maze m) {
    std::vector<Point*> used;
    std::queue<Point*> stack;
    stack.push(m.start);
    Point* current = stack.front();
    stack.pop();
    while(current != m.finish){
        used.push_back(current);
        int x = (*current).x;
        int y = (*current).y;
        if (x + 1 < m.sx) {
            if (m.map[x + 1 + y * m.sx] != -1){
                stack.push(&m.map_p[x + 1 + y * m.sx]);
                if ((m.map_p[x + 1 + y * m.sx]).ptr == nullptr && &m.map_p[x + 1 + y * m.sx] != m.start) {
                    (m.map_p[x + 1 + y * m.sx]).ptr = current;
                }
            }
        }
        if (x - 1 >= 0){
            if (m.map[x - 1 + y * m.sx] != -1) {
                stack.push(&m.map_p[x - 1 + y * m.sx]);
                if ((m.map_p[x - 1 + y * m.sx]).ptr == nullptr && &m.map_p[x - 1 + y * m.sx] != m.start) {
                    (m.map_p[x - 1 + y * m.sx]).ptr = current;
                }
            }
        }
        if (y + 1 < m.sy) {
            if (m.map[x + (y + 1) * m.sx] != -1) {
                stack.push(&m.map_p[x + (y + 1) * m.sx]);
                if ((m.map_p[x + (y + 1) * m.sx]).ptr == nullptr && &m.map_p[x + (y + 1) * m.sx] != m.start) {
                    (m.map_p[x + (y + 1) * m.sx]).ptr = current;
                }
            }
        }
        if (y - 1 >= 0) {
            if (m.map[x + (y - 1) * m.sx] != -1) {
                stack.push(&m.map_p[x + (y - 1) * m.sx]);
                if ((m.map_p[x + (y - 1) * m.sx]).ptr == nullptr && &m.map_p[x + (y - 1) * m.sx] != m.start) {
                    (m.map_p[x + (y - 1) * m.sx]).ptr = current;
                }
            }
        }
        current = stack.front();
        stack.pop();
        while(in(current, used)) {
            current = stack.front();
            stack.pop();
        }

    }

    std::vector<Point*> way;
    way.push_back(current);

    while((*current).ptr != nullptr) {
        Point* next = (*current).ptr;
        current = next;
        way.push_back(current);
    }
    way.push_back(current);
    for(int i = 0; i < way.size(); i++) {
        std::cout << (*way[way.size() - 1 - i]).x << ' ' << (*way[way.size() - 1 - i]).y << std::endl;
    }
}



int main() {
    Maze m;
    m.read("C:/Users/svan5/Desktop/c++/labirint/labirint2.txt");
    //m.read("C:/Users/svan5/Desktop/c++/labirint_final/labirint3.txt");
    depth(m);
    std::cout << "---" << std::endl;
    //m.read("C:/Users/svan5/Desktop/c++/labirint_final/labirint3.txt");
    width(m);
    return 0;
}
