#include <iostream>

int main() {
    //std::cout << "Hello, World!" << std::endl;
    long long int a;
    std::cin >> number;
    int res = 1;
    for (int i = 1; i <= ar) {
        res *= i
    }
    std::cout << res << std::endl;
    return 0;
}